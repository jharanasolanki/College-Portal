<?php
//	if(isset($_POST['submit']))
//	{
		$day=$_POST['day'];
		$fromtime=$_POST['time'].":30";
		$totime=($_POST['time']+1).":30";

?>